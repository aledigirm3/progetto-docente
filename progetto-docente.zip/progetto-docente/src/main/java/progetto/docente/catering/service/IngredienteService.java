package progetto.docente.catering.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import progetto.docente.catering.model.Credentials;
import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.repository.IngredienteRepository;

@Service
public class IngredienteService {
	@Autowired
	private IngredienteRepository ir;

	public boolean alreadyExist(Ingrediente ingrediente) {
		return this.ir.existsByNomeAndOrigineAndPiatto(ingrediente.getNome(), ingrediente.getOrigine(),
				ingrediente.getPiatto());
	}

	public Ingrediente getIngrediente(Long id) {
		return this.ir.findById(id).get();
	}

	public List<Ingrediente> getAllIngredienti() {
		List<Ingrediente> ingredienti = new ArrayList<Ingrediente>();
		for (Ingrediente i : this.ir.findAll())
			ingredienti.add(i);
		return ingredienti;
	}

	@Transactional
	public void saveIngrediente(Ingrediente ingrediente) {
		this.ir.save(ingrediente);

	}

	public void removeIngrediente(Long id) {
		ir.deleteById(id);

	}
}
