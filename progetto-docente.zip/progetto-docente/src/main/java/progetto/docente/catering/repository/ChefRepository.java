package progetto.docente.catering.repository;

import org.springframework.data.repository.CrudRepository;

import progetto.docente.catering.model.Chef;

public interface ChefRepository extends CrudRepository<Chef, Long> {
	
public boolean existsByNomeAndCognomeAndNazionalita(String nome, String cognome, String nazionalita);
}
