package progetto.docente.catering.repository;

import org.springframework.data.repository.CrudRepository;

import progetto.docente.catering.model.Buffet;
import progetto.docente.catering.model.Piatto;

public interface PiattoRepository extends CrudRepository<Piatto, Long> {
public boolean existsByNomeAndDescrizioneAndBuffet(String nome, String descrizione, Buffet buffet);
}
