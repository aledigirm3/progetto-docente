package progetto.docente.catering.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import progetto.docente.catering.model.Buffet;
import progetto.docente.catering.model.Piatto;
import progetto.docente.catering.service.BuffetService;
import progetto.docente.catering.service.CredentialsService;
import progetto.docente.catering.validation.BuffetValidator;

@Controller
public class BuffetController {
	@Autowired
	private BuffetService bs;
	@Autowired
	private BuffetValidator bv;
	@Autowired
	private CredentialsService cService;

	@PostMapping("/saveBuffet")
	public String saveBuffet(@Valid @ModelAttribute("buffet") Buffet buffet, BindingResult br, Model model) {
		this.bv.validate(buffet, br);
		if (!br.hasErrors()) {
			bs.saveBuffet(buffet);
			model.addAttribute("buffet", buffet);
			this.cService.setRoleInModel(model);
			System.out.println(buffet.getChef().getId());
			return "buffet.html";
		}
		return "buffetForm.html";
	}

	@GetMapping("buffet/{id}")
	public String getBuffet(@PathVariable("id") Long id, Model model) {
		Buffet c = bs.getBuffet(id);
		model.addAttribute("buffet", c);
		this.cService.setRoleInModel(model);
		return "buffet.html";
	}

	@GetMapping("/admin/buffetForm")
	public String modificaBuffet(Model model) {
		model.addAttribute("buffet", new Buffet());
		return "buffetForm.html";
	}

	@GetMapping("/buffets")
	public String getBuffets(Model model) {
		List<Buffet> listaB = bs.getAllBuffet();
		model.addAttribute("buffets", listaB);
		this.cService.setRoleInModel(model);
		return "buffets.html";
	}
	
	@GetMapping("/admin/addPiatto/{id}")
	public String addPiatto(@PathVariable("id") Long id, Model model) {
		Piatto p = new Piatto();
		p.setBuffet(bs.getBuffet(id));
		this.bs.getBuffet(id).getPiatti().add(p);
		model.addAttribute("piatto", p);
		return "piattoForm.html";
	}
	@GetMapping("/piattiBuffet/{id}")
	public String elencoPiattiBuffet(@PathVariable("id") Long id, Model model) {
		model.addAttribute("piatti", bs.getPiattiBuffet(bs.getBuffet(id)));
		this.cService.setRoleInModel(model);
		return "piatti.html";
	}
	@GetMapping("/admin/toDeleteBuffet/{id}")
	public String toDeleteBuffet(@PathVariable("id") Long id, Model model) {
		model.addAttribute("buffet", bs.getBuffet(id));
		return "toDeleteBuffet.html";

	}

	@Transactional
	@GetMapping("/deleteBuffet/{id}")
	public String deleteBuffet(@PathVariable("id") Long id, Model model) {
		model.addAttribute("buffets", bs.getBuffetsChef(id));
		bs.removeBuffet(id);
		this.cService.setRoleInModel(model);
		return "buffets.html";
	}
	@GetMapping("/admin/modificaBuffet/{id}")
	public String modificaBuffet(@PathVariable("id") Long id, Model model) {
		model.addAttribute("buffet", this.bs.getBuffet(id));
		return "buffetForm.html";
	}
}
