package progetto.docente.catering.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.model.Piatto;
import progetto.docente.catering.repository.PiattoRepository;

@Service
public class PiattoService {
	@Autowired
	private PiattoRepository pr;
	public List<Piatto> getallPiatti() {
		List<Piatto> piatti = new ArrayList<Piatto>();
		for (Piatto p : pr.findAll())
			piatti.add(p);
		return piatti;
	}

	public boolean alreadyExist(Piatto piatto) {
		return this.pr.existsByNomeAndDescrizioneAndBuffet(piatto.getNome(), piatto.getDescrizione(), piatto.getBuffet());
	}

	public Piatto getPiatto(Long id) {
		return this.pr.findById(id).get();
	}
@Transactional
	public void savePiatto(Piatto piatto) {
		this.pr.save(piatto);
		
	}

	public void removePiatto(Long id) {
		this.pr.deleteById(id);
		
	}

	public List<Piatto> getPiattiBuffet(Long id) {
		return this.pr.findById(id).get().getBuffet().getPiatti();
	}

public List<Ingrediente> getIngredienti(Long id) {
	return this.pr.findById(id).get().getIngredienti();
}
}
