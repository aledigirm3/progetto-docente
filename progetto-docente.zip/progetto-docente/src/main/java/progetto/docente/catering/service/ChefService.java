package progetto.docente.catering.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import progetto.docente.catering.model.Chef;
import progetto.docente.catering.model.Buffet;
import progetto.docente.catering.repository.ChefRepository;

@Service
public class ChefService {
	@Autowired
	private ChefRepository cr;
@Transactional
	public void saveChef(Chef chef) {
	this.cr.save(chef);
//	if(!this.cr.existsById(chef.getId()))
//	this.cr.save(chef);
//	else
//	{
//		Chef ch = this.getChef(chef.getId());
//		ch.setNome(chef.getNome());
//		ch.setCognome(chef.getCognome());
//		ch.setNazionalita(chef.getNazionalita());
//	}
	}

public Chef getChef(Long id) {
	return cr.findById(id).get();
}

	public List<Chef> getAllChef() {
		List<Chef> chefs = new ArrayList<Chef>();
		for (Chef c : cr.findAll())
			chefs.add(c);
		return chefs;
	}
	public boolean alreadyExist(Chef chef) {
		return this.cr.existsByNomeAndCognomeAndNazionalita(chef.getNome(), chef.getCognome(), chef.getNazionalita());
	}
	public void removeChef(Long id) {
		cr.deleteById(id);
	}
	public List<Buffet> getAllBuffetChef(Chef chef){
	return chef.getBuffets();
	}
}
