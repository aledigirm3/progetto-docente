package progetto.docente.catering.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.service.CredentialsService;
import progetto.docente.catering.service.IngredienteService;
import progetto.docente.catering.validation.IngredienteValidator;

@Controller
public class IngredienteController {
	@Autowired
	private IngredienteService is;
	@Autowired
	private IngredienteValidator iv;
	@Autowired
	private CredentialsService cService;
	
	@PostMapping("/saveIngrediente")
	public String saveIngrediente(@Valid @ModelAttribute("ingrediente") Ingrediente ingrediente, BindingResult br,
			Model model) {
		this.iv.validate(ingrediente, br);
		if (!br.hasErrors()) {
			is.saveIngrediente(ingrediente);
			model.addAttribute("piatto", ingrediente.getPiatto());
			this.cService.setRoleInModel(model);
			return "piatto.html";
		}
		return "ingredienteForm.html";
	}

	@GetMapping("/ingrediente/{id}")
	public String getIngrediente(@PathVariable("id") Long id, Model model) {
		Ingrediente c = is.getIngrediente(id);
		model.addAttribute("ingrediente", c);
		return "ingrediente.html";
	}

	@GetMapping("/admin/ingredienteForm")
	public String formIngrediente(Model model) {
		model.addAttribute("ingrediente", new Ingrediente());
		return "ingredienteForm.html";
	}

	@GetMapping("/ingredienti")
	public String getPersone(Model model) {
		List<Ingrediente> listaI = is.getAllIngredienti();
		model.addAttribute("ingredienti", listaI);
		this.cService.setRoleInModel(model);
		return "ingredienti.html";
	}
	@GetMapping("/admin/toDeleteIngrediente/{id}")
	public String toDeleteIngrediente(@PathVariable("id") Long id, Model model) {
		model.addAttribute("ingrediente", is.getIngrediente(id));
		return "toDeleteIngrediente.html";

	}
	

	@Transactional
	@GetMapping("deleteIngrediente/{id}")
	public String deleteIngrediente(@PathVariable("id") Long id, Model model) {
		is.removeIngrediente(id);
		model.addAttribute("ingredienti", is.getAllIngredienti());
		this.cService.setRoleInModel(model);
		return "ingredienti.html";
	}
	@GetMapping("/admin/modificaIngrediente/{id}")
	public String modificaIngrediente(@PathVariable("id") Long id, Model model) {
		model.addAttribute("ingrediente", this.is.getIngrediente(id));
		return "ingredienteForm.html";
	}
}
