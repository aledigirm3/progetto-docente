package progetto.docente.catering.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.service.IngredienteService;
@Component
public class IngredienteValidator implements Validator {
	@Autowired
	private IngredienteService is;

	@Override
	public boolean supports(Class<?> clazz) {
		return Ingrediente.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		if (this.is.alreadyExist((Ingrediente) target))
			errors.reject("ingrediente.duplicato");
	}
}
