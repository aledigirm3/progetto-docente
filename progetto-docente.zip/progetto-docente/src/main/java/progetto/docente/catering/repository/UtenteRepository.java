package progetto.docente.catering.repository;

import org.springframework.data.repository.CrudRepository;

import progetto.docente.catering.model.Utente;

public interface UtenteRepository extends CrudRepository<Utente, Long> {

}
