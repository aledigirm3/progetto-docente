package progetto.docente.catering.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import progetto.docente.catering.model.Buffet;
import progetto.docente.catering.model.Piatto;
import progetto.docente.catering.repository.BuffetRepository;

@Service
public class BuffetService {
	@Autowired
	private BuffetRepository br;

	public List<Buffet> getAllBuffet() {
		List<Buffet> buffets = new ArrayList<Buffet>();
		for (Buffet b : br.findAll())
			buffets.add(b);
		return buffets;
	}

	public boolean alreadyExist(Buffet buffet) {
		return br.existsByNome(buffet.getNome());
	}

	@Transactional
	public void saveBuffet(Buffet buffet) {
			this.br.save(buffet);
	}

	public Buffet getBuffet(Long id) {
		return br.findById(id).get();
	}

	public List<Piatto> getPiattiBuffet(Buffet buffet) {
		return buffet.getPiatti();
	}

	public void removeBuffet(Long id) {
		this.br.deleteById(id);
		
	}
	public List<Buffet> getBuffetsChef(Long id){
		List<Buffet> buffets = new ArrayList<Buffet>();
		buffets = this.br.findById(id).get().getChef().getBuffets();
		return buffets;
	}
}
