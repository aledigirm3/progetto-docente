package progetto.docente.catering.repository;

import org.springframework.data.repository.CrudRepository;

import progetto.docente.catering.model.Buffet;

public interface BuffetRepository extends CrudRepository<Buffet, Long> {
public boolean existsByNome(String nome);
}
