package progetto.docente.catering.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.model.Piatto;
import progetto.docente.catering.service.CredentialsService;
import progetto.docente.catering.service.PiattoService;
import progetto.docente.catering.validation.PiattoValidator;

@Controller
public class PiattoController {
	@Autowired
	private PiattoService ps;
	@Autowired
	private PiattoValidator pv;
	@Autowired
	private CredentialsService cService;

	@PostMapping("/savePiatto")
	public String savePiatto(@Valid @ModelAttribute("piatto") Piatto piatto, BindingResult br, Model model) {
		this.pv.validate(piatto, br);
		if (!br.hasErrors()) {
			ps.savePiatto(piatto);
			model.addAttribute("piatto", piatto);
			this.cService.setRoleInModel(model);
			return "piatto.html";
		}
		return "piattoForm.html";
	}
  
	@GetMapping("/piatto/{id}")
	public String getPiatto(@PathVariable("id") Long id, Model model) {
		Piatto p = ps.getPiatto(id);
		model.addAttribute("piatto", p);
		this.cService.setRoleInModel(model);
		return "piatto.html";
	}
	@GetMapping("/admin/toDeletePiatto/{id}")
	public String toDeletePiatto(@PathVariable("id") Long id, Model model) {
		model.addAttribute("piatto", ps.getPiatto(id));
		return "toDeletePiatto.html";

	}

	@Transactional
	@GetMapping("/deletePiatto/{id}")
	public String deletePiatto(@PathVariable("id") Long id, Model model) {
		model.addAttribute("piatti", ps.getPiattiBuffet(id));
		ps.removePiatto(id);
		this.cService.setRoleInModel(model);
		return "piatti.html";
	}
	@GetMapping("/admin/modificaPiatto/{id}")
	public String modificaPiatto(@PathVariable("id") Long id, Model model) {
		model.addAttribute("piatto", this.ps.getPiatto(id));
		return "piattoForm.html";
	}
	@GetMapping("/admin/addIngrediente/{id}")
	public String addIngrediente(@PathVariable("id") Long id, Model model) {
		Ingrediente i = new Ingrediente();
		i.setPiatto(ps.getPiatto(id));
		this.ps.getPiatto(id).getIngredienti().add(i);
		model.addAttribute("ingrediente", i);
		return "ingredienteForm.html";
	}
	@GetMapping("/getIngredienti/{id}")
	public String getIngredienti(@PathVariable("id") Long id, Model model) {
		model.addAttribute("ingredienti", this.ps.getIngredienti(id));
		this.cService.setRoleInModel(model);
		return "ingredienti.html";
	}
}
