package progetto.docente.catering.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import progetto.docente.catering.model.Buffet;
import progetto.docente.catering.model.Chef;
import progetto.docente.catering.service.ChefService;
import progetto.docente.catering.service.CredentialsService;
import progetto.docente.catering.validation.ChefValidator;

@Controller
public class ChefController {
	@Autowired
	private ChefService cs;
	@Autowired
	private ChefValidator cv;
	@Autowired
	private CredentialsService cService;

	@PostMapping("/saveChef")
	public String saveChef(@Valid @ModelAttribute("chef") Chef chef, BindingResult br, Model model) {
		this.cv.validate(chef, br);
		if (!br.hasErrors()) {
			cs.saveChef(chef);
			model.addAttribute("chef", chef);
			this.cService.setRoleInModel(model);
			return "chef.html";
		}
		return "chefForm.html";
	}

	@GetMapping("/chef/{id}")
	public String getChef(@PathVariable("id") Long id, Model model) {
		Chef c = cs.getChef(id);
		model.addAttribute("chef", c);
		this.cService.setRoleInModel(model);
		return "chef.html";
	}

	@GetMapping("/admin/modificaChef/{id}")
	public String modificaChef(@PathVariable("id") Long id, Model model) {
		model.addAttribute("chef", this.cs.getChef(id));
		return "chefForm.html";
	}

	@GetMapping("/admin/chefForm")
	public String formChef(Model model) {
		model.addAttribute("chef", new Chef());
		return "chefForm.html";
	}

	@GetMapping("/chefs")
	public String getChefs(Model model) {
		List<Chef> listaI = cs.getAllChef();
		model.addAttribute("chefs", listaI);
		this.cService.setRoleInModel(model);
		return "chefs.html";
	}

	@GetMapping("/admin/toDeleteChef/{id}")
	public String toDeleteChef(@PathVariable("id") Long id, Model model) {
		model.addAttribute("chef", cs.getChef(id));
		return "toDeleteChef.html";

	}

	@Transactional
	@GetMapping("/deleteChef/{id}")
	public String deleteChef(@PathVariable("id") Long id, Model model) {
		cs.removeChef(id);
		model.addAttribute("chefs", cs.getAllChef());
		return "chefs.html";
	}

	@GetMapping("/buffetsChef/{id}")
	public String elencoBuffetChef(@PathVariable("id") Long id, Model model) {
		model.addAttribute("buffets", cs.getAllBuffetChef(cs.getChef(id)));
		this.cService.setRoleInModel(model);
		return "buffets.html";
	}

	@GetMapping("/admin/addBuffet/{id}")
	public String addBuffet(@PathVariable("id") Long id, Model model) {
		Buffet b = new Buffet();
		b.setChef(cs.getChef(id));
		cs.getChef(id).getBuffets().add(b);
		model.addAttribute("buffet", b);
		return "buffetForm.html";
	}
}
