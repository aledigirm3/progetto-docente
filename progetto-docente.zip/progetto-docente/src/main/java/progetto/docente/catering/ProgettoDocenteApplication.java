package progetto.docente.catering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoDocenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoDocenteApplication.class, args);
	}

}
