package progetto.docente.catering.repository;

import org.springframework.data.repository.CrudRepository;

import progetto.docente.catering.model.Ingrediente;
import progetto.docente.catering.model.Piatto;

public interface IngredienteRepository extends CrudRepository<Ingrediente, Long> {

	public boolean existsByNomeAndOrigineAndPiatto(String nome, String origine, Piatto piatto);
}
