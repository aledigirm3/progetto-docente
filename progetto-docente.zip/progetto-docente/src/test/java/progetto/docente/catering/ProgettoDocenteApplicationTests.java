package progetto.docente.catering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoDocenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
